import React from 'react'

export default function TabAddDevices() {
    return (
        <div>
            <h5><strong>Add Devices</strong></h5>

        </div>
    )
}
