import React from 'react'

export default function TabChannelDetail() {
    return (
        <div>
            <h5><strong>Channel Detail</strong></h5>
        </div>
    )
}
