import React from 'react'

export default function TabDevicesDetail() {
    return (
        <div>
            <h5><strong>Devices Detail</strong></h5>
        </div>
    )
}
