import React from 'react'

export default function TabAddVideos() {
    return (
        <div>
            <h5><strong>Add Videos</strong></h5>

        </div>
    )
}
