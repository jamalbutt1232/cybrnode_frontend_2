import React, { Component } from 'react'

export default class TabContentChannelDetail extends Component {
    constructor(props){
        super(props)
        this.state= {
            channeldata:[20,30]
            
        }
    }
    render() {
        return (
            <div>
                {   
                    this.state.channeldata.map( x=>{
                        // return <ul>{x.name}</ul>
                        return <ul>{x}</ul>
                    }
                
                )}
            </div>
        )
    }
}
