// Our main component
// we will render all our components here : header, tabs, footer


import React, { Component } from 'react'
import  TabComponent from '../components/TabComponent'

export default class Main extends Component {
    render() {
        return (
            <TabComponent/>
            
        )
    }
}
