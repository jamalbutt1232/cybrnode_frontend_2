import React from 'react'

export default function TabSingleChannel() {
    return (
        <div>
            <div className="card cardsDevicesList">
                <div className="card-body">

                    <h6 className="card-subtitle mb-2 text-muted">Name of the Channel</h6>                               
                    
                </div>
        </div>
            
        </div>
    )
}
