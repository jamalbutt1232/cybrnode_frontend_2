import React from 'react'

export default function TabChannelDetail() {
    return (
        <div>
            <h3><center>Channel</center></h3>
        </div>
    )
}
