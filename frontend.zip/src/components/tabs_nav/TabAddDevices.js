import React from 'react'

export default function TabAddDevices() {
    return (
        <div >
            <h3><center>Add Devices</center></h3>
                    
        </div>
    )
}
