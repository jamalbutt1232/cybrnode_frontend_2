import React from 'react'

export default function TabAddVideos() {
    return (
        <div>
            <h3><center>Media</center></h3>

        </div>
    )
}
