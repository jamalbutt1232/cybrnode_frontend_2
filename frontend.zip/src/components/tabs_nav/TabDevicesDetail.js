import React from 'react'

export default function TabDevicesDetail() {
    return (
        <div>
            <h3><center>Device Detail</center></h3>
        </div>
    )
}
