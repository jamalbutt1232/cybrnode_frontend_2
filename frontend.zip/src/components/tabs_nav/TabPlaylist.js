import React from 'react'

export default function TabChannelDetail() {
    return (
        <div>
            <h3><center>Playlist</center></h3>
        </div>
    )
}
